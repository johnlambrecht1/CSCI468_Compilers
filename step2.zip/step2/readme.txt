
Please follow the below listed documentation to run an error-free program

	1.Place the inputs and outputs folder inside the step2 folder
	
	2.Open linux terminal
	
	3.Change the directory of the terminal to step2
	
	4.Run the shell script in the following manner.
		$./Grading_Script.sh
	
	5.That should run and display the differences between the genrated files and the given files.
	
	6.If the files are identical the parser has done it's job. WELL DONE!  

	
Note: The ANTLR tool has a runtime error but it doesn't affect the results produced by the parser or the job of the parser.

Also for convinience the inputs and outputs has been placed inside for step2.
