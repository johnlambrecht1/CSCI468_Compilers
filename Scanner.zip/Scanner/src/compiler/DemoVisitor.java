package compiler;

import compiler.littleParser.ProgramContext;

public class DemoVisitor extends littleBaseVisitor<Object>{
/*
	public Object visitProgram(ProgramContext ctx) {
		int i = 0;
		visitChildren(ctx);
		if (ctx.getChildCount() == 1) {
			System.out.println(ctx.getChild(0));
		}
		else {
			do {
			//System.out.println(ctx.getChild(i));
			//System.out.println("Success");
			i++;
			}
			while(ctx.getChild(i) != null);
		}
		return null;
	}
*/
	public Object visitStmt_list(ProgramContext ctx) {
		int i = 0;
		visitChildren(ctx);
		if (ctx.getChildCount() == 1) {
			System.out.println(ctx.getChild(0));
		}
		else {
			do {
			System.out.println(ctx.getChild(i));
			//System.out.println("Success");
			i++;
			}
			while(ctx.getChild(i) != null);
		}
		return null;
	}

}